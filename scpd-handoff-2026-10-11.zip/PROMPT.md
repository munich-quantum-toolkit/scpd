You are working in my local clone of `munich-quantum-toolkit/scpd`, on the
branch `phase-4-routing-stages` (phase 4: the routing stages). Work only on
that branch; do not switch to another branch or push. A cloud session worked
on the same branch, on the capacity check of the coupler insertion (Final
stage), and could not commit its work. I unpacked its handoff archive into
`<HANDOFF DIR>` (replace with the real path). It holds:

- `HANDOFF.md`: what the work changes, why, how to build and test it, the
  results to expect and the open points. Read it in full first.
- `scpd-capacity-check.patch`: every change, against commit `9f68160`.
- `scpd-2026-10-11-final.tar.gz`: the whole working tree, in case the patch
  does not apply.
- `bench/run-benchmarks.sh` and `bench/report.py`: the benchmark runs and
  their report, exactly as the cloud session ran them.
- `benchmark-report.md`: the cloud session's results.

Read `AGENTS.md` and `docs/ai_usage.md` in the repository before you start,
and follow them.

Do this, in this order:

1. **Apply.** Check that `phase-4-routing-stages` is checked out and that its
   head is commit `9f68160` (`git log -1`). If the branch has moved on,
   stop and tell me before you apply anything. Run `git apply --check` on
   the patch, then `git apply`. Do not change the patch's content to make it apply; if it
   does not apply, stop and tell me why.

2. **Build and test.** Configure and build the release preset, build the
   Python package (`uv sync --inexact --no-dev --no-build-isolation-package
   mqt-scpd`, with `--reinstall-package mqt-scpd` if it does not rebuild).
   Run the new and changed tests named in `HANDOFF.md` first, then
   `ctest --preset release -E EveryChip`. Two tests failed on the base
   commit already (named in `HANDOFF.md`): check them on `9f68160` before you
   count them against the patch. Every other failure is a finding; report it
   with its output.

3. **Lint.** Run the `prek` hooks on the changed files only, not on all
   files (see `HANDOFF.md`: a full run reformats about 130 unrelated files).
   After the lint, `git status` must show only the patch's files. Fix
   findings in the patch's files; leave every other file as it is.

4. **Benchmarks, yourself.** From the repository root run
   `<HANDOFF DIR>/bench/run-benchmarks.sh <out dir>` for all eight chips
   (4q, 9q, 17q, 21q, 33q, 45q, 57q, 69q). It runs one chip at a time with
   the capacity rule and the profile cuts and `stop_after = "feedlines"`.
   Run nothing else heavy on the machine meanwhile: the chain search has a
   wall-clock budget of 10 s per chain, so other load changes the results.
   69q takes the longest (about 30 minutes in the cloud, probably 10-15 on
   this machine). Then run `python3 <HANDOFF DIR>/bench/report.py <out dir>`.

5. **Check the results.** For every chip check and report:
   - **bad** = unrouted + open + crossing a feedline: must be 0;
   - every feedline edge drawn (0 not drawn);
   - the capacity graph after the insertion: must be **SAT** (no wire
     without a way, none too long, no edge over);
   - short and long wires, the feedline angle cost and which chains were
     searched again without the rule, each against the cloud value;
   - the runtime of the insertion and of the whole run, against the cloud
     value.
   `report.py` exits 1 and names the chip when bad > 0, an edge is not drawn
   or a graph is UNSAT. A faster machine prices more steps in the same budget,
   so angle costs and short/long counts may differ a little from the cloud
   values; bad, edges not drawn and SAT may not. If a chip fails, do not
   change code: tell me which chip, what failed, and the lines of its log
   (`<out dir>/<chip>.log`) that say so.

6. **Prepare the commit, but do not commit.** Add the pull request reference
   and the author to the new `CHANGELOG.md` entries only once a pull request
   exists; until then, tell me that they are missing. Draft a commit message
   (what changed and why, in the repository's style) and show it to me. I
   commit myself.

At the end, give me one report: the test results, the lint result, the
benchmark table from `report.py` with the cloud values beside yours, the
runtimes, and anything that differs from `HANDOFF.md`.
