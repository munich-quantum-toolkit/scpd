# Handoff: fast capacity check and capacity-rule fixes

Hand this file and `scpd-capacity-check.patch` to the agent that applies the
work in your local clone of `munich-quantum-toolkit/scpd`. The work is not
committed anywhere. The repository's `AGENTS.md` applies: read it first.

## Base

- Base commit: `9f68160` ("✨ Move coupler options into the box and keep each
  chain from crossing itself"), branch `phase-4-routing-stages`.
- The patch holds 15 files: 12 changed and 3 new
  (`include/mqt-scpd/grid/ProfileCuts.hpp`, `src/grid/ProfileCuts.cpp`,
  `test/grid/test_profile_cuts.cpp`). The CMake targets glob their sources, so
  no `CMakeLists.txt` changes.
- `scpd-<date>.tar.gz` holds the whole working tree (without `build/` and
  `.venv/`) in case the patch does not apply.

## Apply

```sh
git switch phase-4-routing-stages   # or a new branch from 9f68160
git apply --check scpd-capacity-check.patch
git apply scpd-capacity-check.patch
```

## Build and test

```sh
cmake --preset release
cmake --build --preset release
./build/release/test/grid/mqt-scpd-grid-test --gtest_filter='ProfileCuts.*:NearestBlocked.*:Chambers.*'
./build/release/test/pipeline/mqt-scpd-pipeline-test --gtest_filter='CapacityFlow.*:InTurn.*:FinalRouter.*:CouplerSession.*'
ctest --preset release -E EveryChip
```

Before this work, `ctest -E EveryChip` had two failures that this work does
not touch: `FinalRouter.OnlyUnsettledRedrawsOneWire` and
`CouplerInsertion.ASecondDoglegOffersAnotherPlacement` (anchor 580 against
581). Check them against the base commit before you blame the patch.

Lint: `uvx nox -s lint` runs `prek` on **all** files. In the cloud session it
reformatted about 130 files the work does not touch (a newer `clang-format`
and `rumdl` than the repository was formatted with) and failed in files
outside this work. Run the hooks on the changed files only, or check that
`git status` shows only the patch's files after the lint, and revert the
rest. The patch's own C++ is formatted with the repository's
`.clang-format`; `typos` passes on every changed file.

## What changes

All of it is in the coupler insertion of the Final stage
(`src/pipeline/FinalRouter.cpp`) unless said otherwise.
`handover-capacity-check.md` sections 9-14 hold the reasons, the
measurements and the open points; `CHANGELOG.md` has the user-facing entries.

1. **Fast capacity check (`SCPD_CAPACITY_FAST=1`).** `grid::profileCuts`
   (new) finds the bottlenecks along the walls the insertion moves, against
   two feature transforms (`grid::nearestBlocked`, new in
   `DistanceTransform`) built once per insertion, with no medial axis per
   check. `SCPD_CAPACITY_FAST=2` runs both and logs where they disagree.
   `grid::chambersOf` labels chambers by runs with a union-find (same
   chambers, same order as the flood). The walls keep the border, the artwork
   and the port runs from check to check. 17q: a check 0.40-0.51 s → 0.017-0.057 s.
2. **Open chains.** A chain the search has laid only in part
   (`Edge::open`) is prescribed to no wire: its end is open and its edges
   separate nothing yet.
3. **Terminal edges are no limit.** An edge from or to a launcher is laid
   again by the feedline routing. A bottleneck with an end on one takes every
   wire, and every wire may cross one (stretches open to all, capacity of all
   wires, prescribed to none). The graph JSON marks both `"terminal": true`.
4. **End pair the other way round in the commit.** When the search runs out
   of time and a chain is committed as it stood, an end edge with no way after
   its predecessor is laid first and the predecessor routed again (as the
   chain search already did).
5. **Feedlines with a reflector.** A chain with one launcher is logged
   (`chain 3: one launcher, a reflector at its first end`). The fences, the
   end-pair reorder and the fresh routing of end edges ask
   `atLauncher(chain, at)` instead of "first or last edge". In the capacity
   graph an edge of such a chain keeps stretches with one chamber on both
   sides (a stretch back into the same chamber); `checkInTurn` in
   `src/pipeline/CapacityFlow.cpp` now takes such an edge as a crossing.
6. **Diagnostics.** `SCPD_CAPACITY_STEP_GRAPHS=1` (with
   `SCPD_CAPACITY_STEP` or `SCPD_CAPACITY_RULE`, and `--debug`) writes the
   capacity graph at every edge of a settled chain
   (`step-c<chain>-f<edge>-capacity-graph.json`) and of the first three steps
   per chain that close a wire (`step-c<chain>-closing<k>-…`). A step that
   closes a wire names the feedline edges its edge meets. The JSON opens with
   `python -m mqt.scpd.capacityview <json> -o page.html`.

## New tests

- `test/grid/test_profile_cuts.cpp` (8 tests), `NearestBlocked.*` (2),
  `Chambers.ABottleneckRefusesEveryStepAcrossItsLine`,
  `Chambers.LabelEveryCellAsAFloodFromTheLowestCellWould`.
- `FinalRouter.TheStepCheckPrescribesNoCrossingOfAnOpenChain` (9q).
- `FinalRouter.ATerminalEdgeTakesEveryWire` (9q).
- `InTurn.AWireCrossesAFeedlineWithOneChamberOnBothSides`,
  `InTurn.AWireOfFixedLengthCrossesAFeedlineWithOneChamberOnBothSides`.
- `FinalRouter.DrawsTheCapacityGraphAfterTheBottlenecks` now lets a way
  cross a terminal edge beside its prescribed ones.

Every new test was checked to fail without its change. No test covers the
end-pair reorder in the commit or a reflector chain end to end: the test
chips 4q and 9q have neither case.

## Expected results

Run each chip alone, one after another (the chain search has a wall-clock
budget, `SCPD_CHAIN_ASTAR_SECONDS`, 10 s per chain; parallel runs and other
load change the results). `bench/run-benchmarks.sh <out dir>` does exactly
that from the repository root, and `python3 bench/report.py <out dir>` prints
the table beside the cloud values and exits 1 on a bad wire, an edge not drawn
or an UNSAT graph. Configuration of the runs:

```sh
SCPD_CAPACITY_RULE=1 SCPD_CAPACITY_FAST=1 SCPD_BOTTLENECKS=1 SCPD_SEARCH_PICTURES=0 \
  mqt-scpd plan -c <chip config with stop_after = "feedlines"> -o <run dir> -v 0
```

Results in the cloud session (Intel Xeon 2.1 GHz, one core per run), 2026-10-11:

| Chip | Bad (unrouted/open/crossing) | Short | Long | Wires drawn | Edges not drawn | Angle cost | Capacity graph | Chains settled under the rule | Chains searched again without it | Insertion | Whole run |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 4q | 0 | 1 | 0 | 17/17 | 0 | 8 | SAT | 1/1 | – | 1.1 s | 7 s |
| 9q | 0 | 1 | 0 | 46/46 | 0 | 16 | SAT | 2/2 | – | 2.3 s | 27 s |
| 17q | 0 | 5 | 0 | 92/92 | 0 | 53 | SAT | 4/4 | – | 17.0 s | 64 s |
| 21q | 0 | 3 | 0 | 104/104 | 0 | 50 | SAT | 5/5 | – | 11.9 s | 154 s |
| 33q | 0 | 10 | 0 | 158/158 | 0 | 76 | SAT | 7/7 | – | 30.3 s | 216 s |
| 45q | 0 | 12 | 0 | 209/209 | 0 | 109 | SAT | 8/8 | – | 84.0 s | 508 s |
| 57q | 0 | 29 | 0 | 267/267 | 0 | 138 | SAT | 8/9 | 4 | 117.5 s | 719 s |
| 69q | 0 | 34 | 1 | 322/322 | 0 | 180 | SAT | 12/12 | – | 243.7 s | 1884 s |

Before this work (same configuration, first run of the session): 33q 2 bad, 45q 4,
57q 1, 69q 3 (open 183, 184 in its first complete run); graphs UNSAT on 45q,
57q and 69q; angle costs 8, 16, 55, 54, 80, 126, 142, 182.

A faster machine prices more steps in the same budget, so a chain that runs
out of time here (57q chain 4) may settle differently there; angle costs and
short/long counts may then differ a little.

## Open points

- 57q chain 4 runs out of time under the rule and again without it; the
  commit's end-pair reorder draws its edge f33.
- Gaps of 9-15 cells between a feedline edge and the pad or lead of the
  coupler beside it take no wire (33q chain 1 f6, 57q chain 6 f54, 45q
  chain 3 f22). Whether that is right is open.
- `SCPD_CAPACITY_FAST` is off by default; the switch defaults are the
  user's call.

## Before you open a pull request

- Add the pull request reference and the author to the new `CHANGELOG.md`
  entries, as `AGENTS.md` asks (`([#123]) ([**@username**])`), and define the
  link at the bottom.
- Disclose the AI assistance in the pull request description and begin it
  with `🤖 *AI text below* 🤖`.
- A human reviews and understands the work (`docs/ai_usage.md`).
