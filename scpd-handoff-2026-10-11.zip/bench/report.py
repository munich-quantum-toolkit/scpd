"""Report the benchmark runs of run-benchmarks.sh and compare them with the cloud session.

Usage: python3 bench/report.py <out dir>

Exits 1 when a chip has a bad wire, a feedline edge not drawn or an UNSAT
capacity graph, or did not finish.
"""

import re
import sys
from pathlib import Path

OUT = Path(sys.argv[1])
CHIPS = ["4q", "9q", "17q", "21q", "33q", "45q", "57q", "69q"]
# The cloud session, 2026-10-11 (Intel Xeon 2.1 GHz, one core per run):
# angle cost, short, long, seconds of the whole run.
CLOUD = {
    "4q": (8, 1, 0, 7), "9q": (16, 1, 0, 27), "17q": (53, 5, 0, 64), "21q": (50, 3, 0, 154),
    "33q": (76, 10, 0, 216), "45q": (109, 12, 0, 508), "57q": (138, 29, 0, 719), "69q": (180, 34, 1, 1884),
}
seconds = {}
done = OUT / "done.txt"
if done.exists():
    for line in done.read_text().splitlines():
        parts = line.split()
        if len(parts) >= 4 and parts[1] == "exit":
            seconds[parts[0]] = (int(parts[2]), int(parts[3].rstrip("s")))

failed = []
print("| Chip | Bad (u/o/c) | Short | Long | Wires drawn | Edges not drawn | Angle cost (cloud) | Capacity graph | No way / too long / short by | Chains settled | Searched again without the rule | Insertion | Whole run (cloud) |")
print("|---|---|---|---|---|---|---|---|---|---|---|---|---|")
for chip in CHIPS:
    log = OUT / f"{chip}.log"
    if not log.exists():
        continue
    t = log.read_text(errors="replace")
    m = re.search(r"final routing: (\d+) of (\d+) drawn, (\d+) unrouted[^,]*, (\d+) open, (\d+) short(?:, (\d+) long)?(?:, (\d+) crossing)?", t)
    ins = re.search(r"==> coupler insertion: (\d+) feedline edges? NOT drawn, feedline angle cost (\d+), ([0-9.]+)s", t)
    g = re.search(r"CAPACITY GRAPH (SAT|UNSAT)[^\n]*", t)
    st = re.search(r"(\d+) of (\d+) chains settled", t)
    again = re.findall(r"\[Coupler Insertion\] chain (\d+): [^\n]*searched again without the capacity rule", t)
    code, secs = seconds.get(chip, (None, None))
    if not m or not ins or not g:
        failed.append(f"{chip}: no result (exit {code})")
        print(f"| {chip} | no result | | | | | | | | | | | |")
        continue
    u, o, s, l, c = int(m.group(3)), int(m.group(4)), int(m.group(5)), int(m.group(6) or 0), int(m.group(7) or 0)
    bad = u + o + c
    line = g.group(0)
    nw = re.search(r"no way in the graph for ([0-9 ]+)", line)
    ln = re.search(r"no way within its length for ([0-9 ]+)", line)
    sh = re.search(r"short by (\d+) wires?", line)
    angle, cs, cl, csecs = CLOUD[chip]
    if bad:
        failed.append(f"{chip}: {bad} bad")
    if int(ins.group(1)):
        failed.append(f"{chip}: {ins.group(1)} feedline edges not drawn")
    if g.group(1) != "SAT":
        failed.append(f"{chip}: capacity graph UNSAT")
    print(
        f"| {chip} | {'**' + str(bad) + '**' if bad else 0} ({u}/{o}/{c}) | {s} ({cs}) | {l} ({cl}) | {m.group(1)}/{m.group(2)} | {ins.group(1)} | "
        f"{ins.group(2)} ({angle}) | {g.group(1)} | {len(nw.group(1).split()) if nw else 0} / {len(ln.group(1).split()) if ln else 0} / "
        f"{sh.group(1) if sh else 0} | {st.group(0) if st else '–'} | {', '.join(again) or '–'} | {float(ins.group(3)):.1f} s | "
        f"{str(secs) + ' s' if secs is not None else '–'} ({csecs} s) |"
    )
print()
if failed:
    print("FAILED: " + "; ".join(failed))
    sys.exit(1)
print("Every chip: 0 bad, every feedline edge drawn, capacity graph SAT.")
