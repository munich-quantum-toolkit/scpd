#!/usr/bin/env bash
# Run the benchmark chips one after another, as in the cloud session.
#
# Usage, from the repository root:  bench/run-benchmarks.sh <out dir> [chip ...]
# Default chips: 4q 9q 17q 21q 33q 45q 57q 69q. Each chip's config is copied
# from benchmarks/<chip>/ with stop_after = "feedlines". Runs one chip at a
# time: the chain search has a wall-clock budget, so parallel runs or other
# load change the results.
set -u
out=${1:?usage: bench/run-benchmarks.sh <out dir> [chip ...]}
shift
chips=("$@")
[ ${#chips[@]} -eq 0 ] && chips=(4q 9q 17q 21q 33q 45q 57q 69q)
cli=${MQT_SCPD:-.venv/bin/mqt-scpd}
mkdir -p "$out/configs"
for chip in "${chips[@]}"; do
  cfg="$out/configs/$chip"
  mkdir -p "$cfg"
  cp "benchmarks/$chip/config.toml" "benchmarks/$chip/routing_config.json" "$cfg/"
  python3 - "$cfg/config.toml" <<'PY'
import re, sys
p = sys.argv[1]
s = open(p).read()
s, n = re.subn(r'(?m)^stop_after\s*=.*$', 'stop_after    = "feedlines"', s)
assert n == 1, f"{p}: no stop_after line"
open(p, "w").write(s)
PY
  rm -rf "$out/$chip"
  start=$(date +%s)
  SCPD_CAPACITY_RULE=1 SCPD_CAPACITY_FAST=1 SCPD_BOTTLENECKS=1 SCPD_SEARCH_PICTURES=0 \
    "$cli" plan -c "$cfg/config.toml" -o "$out/$chip" -v 0 > "$out/$chip.log" 2>&1
  code=$?
  echo "$chip exit $code $(( $(date +%s) - start ))s" | tee -a "$out/done.txt"
done
